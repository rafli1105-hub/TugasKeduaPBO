/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package mahasiswa;

/**
 *
 * @author MS
 */
public class mahasiswaalague extends manusia implements belajar, bermain, mengerjakantugas{

    public mahasiswaalague(String nama, int umur){
        super(nama, umur);
    }

    public void mulaibelajar() {
       System.out.println(nama +" mulai belajar di perpustakaan.");
    }

    
    public void istirahat() {
        System.out.println(nama +" istirahat sejenak dari belajar.");
    }

    
    public void selesaibelajar() {
        System.out.println(nama +" selesai belajar dan pulang.");
    }

    
    public void mulaibermain() {
        System.out.println(nama +" mulai bermain paruh waktu.");
    }

    
    public void istirahatbermain() {
       System.out.println(nama +" istirahat dari bermain.");
    }

    
    public void selesaibermain() {
         System.out.println( nama +" selesai bermain untuk hari ini.");
    }

    
    public void mulaimengerjakantugas() {
        System.out.println(nama +" mulai mengerjakan tugas paruh waktu.");
    }

    
    public void istirahatmengerjakantugas() {
        System.out.println(nama +" istirahat mengerjakan tugas paruh waktu.");
    }

    
    public void selesaimengerjakantugas() {
       System.out.println(nama +" selesai bekerja untuk hari ini.");
    }
     public static void main(String[] args) {
         
        mahasiswaalague mhs = new mahasiswaalague("Rafli", 19);
        mhs.mulaibelajar();
        mhs.istirahat();
        mhs.selesaibelajar();
        mhs.mulaimengerjakantugas();
        mhs.istirahatmengerjakantugas();
        mhs.selesaimengerjakantugas();
        mhs.mulaibermain();
        mhs.istirahatbermain();
        mhs.selesaibermain();
    }
}
