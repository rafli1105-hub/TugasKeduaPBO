/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package mahasiswa;

/**
 *
 * @author MS
 */
public interface mengerjakantugas {
    void mulaimengerjakantugas();
    void istirahatmengerjakantugas();
    void selesaimengerjakantugas();
}
