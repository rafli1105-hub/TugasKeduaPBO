/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package hariketigadua;

/**
 *
 * @author ACER
 */
public abstract class hewan {
    String nama;

    public hewan(String nama) {
        this.nama = nama;
    }
    
    public abstract void suara();


    public void info() {
        System.out.println("Ini adalah hewan bernama " + nama);
    }
}
