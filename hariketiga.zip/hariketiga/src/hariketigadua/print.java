/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package hariketigadua;

/**
 *
 * @author ACER
 */
public class print {
    public static void main(String[] args) {
        burung merpati = new burung("Merpati");

        // Panggil method hasil override
        merpati.suara();  

        // Panggil method hasil overload
        merpati.suara("pagi hari");  
        merpati.suara(3);            

        // Method warisan dari Hewan
        merpati.info();
    }
}
