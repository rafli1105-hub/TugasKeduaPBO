/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package hariketigadua;

/**
 *
 * @author ACER
 */
public class burung extends hewan {
    
    public burung(String nama) {
        super(nama);
    }

    @Override
    public void suara() {
        System.out.println(nama + " berkicau merdu.");
    }

    // 🔹 Overload method suara()
    public void suara(String waktu) {
        System.out.println(nama + " berkicau di " + waktu);
    }

    public void suara(int jumlah) {
        System.out.println(nama + " berkicau sebanyak " + jumlah + " kali.");
    }
}
