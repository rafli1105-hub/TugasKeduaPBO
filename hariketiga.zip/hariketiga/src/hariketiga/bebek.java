/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package hariketiga;

/**
 *
 * @author ACER
 */
public class bebek extends burung implements terbang, makan, berjalan {

    public bebek(String nama) {
      super(nama);
 }

    @Override
    public void flying() {
        System.out.println(nama + " terbang rendah.");
    }

    @Override
    public void eating() {
        System.out.println(nama + " memakan biji-bijian.");
    }
    
    @Override
    public void walkable() {
        System.out.println(nama + " berjalan sambil bergoyang.");
    }

    @Override
    public void bertelur() {
        System.out.println(nama + "mengerami");
    }

    @Override
    public void makeSound() {
        System.out.println(nama + "Menguak");
    }

}
