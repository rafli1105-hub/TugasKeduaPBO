/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package hariketiga;

public class print {
    public static void main(String[] args) {
        bebek bebek = new bebek("Bebek Angsa");
        bebek.bertelur();
        bebek.makeSound();
        bebek.walkable();
        bebek.eating();
        bebek.flying();
        
    }
}
